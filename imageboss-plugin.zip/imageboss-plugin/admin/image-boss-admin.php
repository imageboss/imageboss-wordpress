<?php

require_once plugin_dir_path(__FILE__) . '/includes/plugin-activation.php';
require_once plugin_dir_path(__FILE__) . '/includes/assets-setup.php';
require_once plugin_dir_path(__FILE__) . '/includes/menu-customization.php';
require_once plugin_dir_path(__FILE__) . '/includes/settings-group.php';
require_once plugin_dir_path(__FILE__) . '/includes/add-media-widget-customization.php';
require_once plugin_dir_path(__FILE__) . '/screens/welcome.php';
require_once plugin_dir_path(__FILE__) . '/screens/settings.php';
